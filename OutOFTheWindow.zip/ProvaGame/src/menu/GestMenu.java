package menu;

import classifica.Partita;
import classifica.ShlClassifica;
import classifica.VetClassifica;
import levels.MainGame;

public class GestMenu {
	public static GestMenu gest;
	private static final int NUMLEVEL = 3;
	private Menu menu;
	private SceltaClassifica c;
	private InNome inNome;
	private SceltaLivelli s;
	private String namePlayer;
	private Win win;
	private MainGame currentLevel;
	
	
	private ShlClassifica[] classsifica = new ShlClassifica[NUMLEVEL];
	private VetClassifica v = VetClassifica.load("classifiche.bin");
	
	public void start() {
		gest = this;
		openMenu();
	}
	
	
	public void openMenu() {
		if(menu == null) {
			menu = new Menu();
			menu.start();	
			return;
		}
		
		menu.openAll();
	}
	
	public void closeMenu() {
		if(menu == null)return;
		
		menu.closeAll();
	}
	
	public void openSceltaClassifica() {
		if(c == null) {
			c = new SceltaClassifica(menu);
			c.start();		
			return;
		}
		c.setVisible();
		
	}
	
	public void closeSceltaClassifica() {
		if(c == null) return;
		c.closeAll();
	}
	
	
	public void openInNome() {
		if(inNome == null) {
			inNome = new InNome(menu);
			return;
		}
		inNome.setVisible();
		
	}
	public void closeInNome() {
		if(inNome == null) return;
		inNome.closeAll();
	}
	
	
	public void openSceltaLivelli() {
		if(s == null) {
			s = new SceltaLivelli(menu);
			s.start();
			return;
		}
		s.setVisibile();
	}
	public void closeSceltaLivelli() {
		if(s == null) return;
		s.closeAll();
	}
	
	public void setNome(String nome) {
		this.namePlayer = nome;		
		openSceltaLivelli();
	}
	
	public void openLivello(int Num) {
		currentLevel = new MainGame(namePlayer, Num);
	}
	
	public void openWin(long time) {
		if(win == null) {
			win = new Win(time,menu);
			currentLevel.stopGameLoop();
			currentLevel = null;
			return;
		}
		win.setVisible();
		currentLevel.stopGameLoop();
		currentLevel = null;
		
	}
	public void closeWin() {
		win.closeAll();
	}
	int lastopen;
	public void openClassifica(int numClassifica) {
		lastopen = numClassifica-1;
		v = VetClassifica.load("classifiche.bin");
		if(classsifica[lastopen] == null) {
			v.getC(lastopen).add(new Partita("null", 999999999));
			v.getC(lastopen).add(new Partita("null", 999999999));
			v.getC(lastopen).add(new Partita("null", 999999999));
			
			classsifica[lastopen] = new ShlClassifica(v .getC(numClassifica-1), menu);
			return;
		}
		classsifica[lastopen].openAll();
		
	}
	public void closeClassifica() {
		classsifica[lastopen].closeall();
	}
}

package menu;

import java.awt.*;

import javax.swing.JFrame;

public class Menu extends Thread {

	static int LARGHEZZA = -120;
	final static int nFrame = 7;
	static int DELAY=20;
	private JFrame[] frame = new JFrame[nFrame];
	private FrameSelectionListener[] input = new FrameSelectionListener[nFrame];
	private GamePanel[] panel = new GamePanel[nFrame];
	//private Menu menu;
	
	public Menu() {
	}	
	public void run() {
		intiMenu();
		drawLogo();
	}
	
	void intiMenu() {
		for (int i = 0; i < nFrame; i++) {
			frame[i] = new JFrame("frame"+i);
			panel[i] = new GamePanel();

			frame[i].add(panel[i]);
		}

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

		frame[0].setLocation(screenSize.width / 2 - 100 + LARGHEZZA, screenSize.height / 2 - 400);
		frame[0].setSize(600, 400);
		
		frame[1].setLocation(screenSize.width / 2 - 400 + LARGHEZZA, screenSize.height / 2 - 500);
		frame[1].setSize(350, 800);
		
		frame[2].setLocation(screenSize.width / 2 - 200 + LARGHEZZA, screenSize.height / 2 - 20);
		frame[2].setSize(650, 400);
		frame[2].setUndecorated(true);
		
		frame[3].setLocation(screenSize.width / 2 + 350 + LARGHEZZA, screenSize.height / 2 - 300);
		frame[3].setSize(300, 700);

		frame[4].setLocation(screenSize.width / 2 - 400 + LARGHEZZA, screenSize.height - 150);
		frame[4].setSize(310, 130);
		
		frame[5].setLocation(screenSize.width / 2 - 30 + LARGHEZZA,  screenSize.height - 150);
		frame[5].setSize(310, 130);
		
		frame[6].setLocation(screenSize.width / 2 + 300 + LARGHEZZA,  screenSize.height - 150);
		frame[6].setSize(310, 130);
	}
	void drawLogo() {
		for (int i = 0; i < nFrame; i++) {
			frame[i].setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame[i].setResizable(false);
			input[i] = new FrameSelectionListener(frame[i].getTitle());
			frame[i].addWindowFocusListener(input[i]) ;
			frame[i].requestFocusInWindow(null);
			
			frame[i].setVisible(true);
			switch (i) {
				case 0:
					panel[0].paint(-300, -100, 1050, 900,"LogoConGriglia");
					break;
				case 1:
					panel[1].paint(0, 0, 1050, 900,"LogoConGriglia");
					break;
				case 2:
					panel[2].paint(-192, -450, 1050, 900,"LogoConGriglia");
					break;
				case 3:
					panel[3].paint(-750, -200, 1050, 900,"LogoConGriglia");
					break;
				case 4:
					panel[4].paint(0, 0, 300, 100,"scoreboard");
					break;
				case 5:
					panel[5].paint(-10, -10, 320, 120,"play");
					break;
				case 6:
					panel[6].paint(0, 0, 300, 100,"settings");
					break;
			}
			try {
				Thread.sleep(DELAY);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
 	public void closeAll() {
		for (int i = 0; i < nFrame; i++) {
			input[i].setSelected(0);
			frame[i].dispose();
		}
	}
 	public void openAll() {
		for (int i = 0; i < nFrame; i++) {
			input[i].setSelected(0);
			frame[i].setVisible(true);
			frame[i].requestFocusInWindow(null);	
		}
 	}
}

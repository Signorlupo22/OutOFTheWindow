package Ui;

public class MenuButton {

}

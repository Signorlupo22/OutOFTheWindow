package Debug;

public class DisplayShell {
	//voglio creare un altra shell che mostra dove sono le altre shell in base allo schermo 
}

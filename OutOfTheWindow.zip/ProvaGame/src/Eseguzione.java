import MainGame.MainGame;
import WindowLogic.*;

public class Eseguzione {

	public static void main(String[] args) {
		 ///crea oggetto maingame ()
	}

}

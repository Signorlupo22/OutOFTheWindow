package menu;

public class Setting {

}

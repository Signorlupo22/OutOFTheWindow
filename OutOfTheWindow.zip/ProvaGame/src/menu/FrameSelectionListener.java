package menu;

import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

import javax.swing.JFrame;

import MainGame.MainGame;
import classifica.*;

public class FrameSelectionListener implements WindowFocusListener {
	private static int sceltaClassifica = 0, scelta = 0, sceltaLV = 0;
	private static Menu menu2;
	private SceltaClassifica classifica;
	private static String nomePlayer;
	public VetClassifica v = VetClassifica.load("classifiche.bin");
	private SceltaLivelli s;
	private String shellname;
	private SceltaClassifica c;
	private InNome inNome;

	/*
	 * public void setMenu() { menu2.getMenu(menu2);; }
	 */
	public FrameSelectionListener() {
	}

	public FrameSelectionListener(Menu m, String name) {
		menu2 = m;
		shellname = name;
	}

	public FrameSelectionListener(SceltaLivelli l, String name) {
		s = l;
		shellname = name;
	}

	public FrameSelectionListener(SceltaClassifica c,String name) {
		classifica = c;
		shellname = name;
	}

	int selected = 0;

	public void windowGainedFocus(WindowEvent e) {
		if (!(e.getSource() instanceof JFrame))
			return;
		selected++;

		if (selected <= 1)
			return;

		JFrame selectedFrame = (JFrame) e.getSource();
		String title = selectedFrame.getName();
		System.out.println(selectedFrame.getTitle() + shellname);

		if (shellname.equals("frameLV1") || shellname.equals("frameLV2") || shellname.equals("frameLV3"))
			s.closeAll();
		if(shellname.equals("frame4")||shellname.equals("frame5")||shellname.equals("frame6"))
			menu2.closeAll();
		
		switch (shellname) {

		case "frame4":
			AvvioSceltaCla();
			break;
		case "frame5":
			if(inNome == null) {
				inNome = new InNome(this, menu2);		
				inNome.setVisible(true);
			}else {
				inNome.setVisible();				
			}
			break;
		case "frameLV1":
			System.out.println("frame1");
			if(s != null)
				new MainGame(nomePlayer, 1,menu2);
			break;
		case "frameLV2":
			if(s != null)
				new MainGame(nomePlayer, 2,menu2);
			break;
		case "frameLV3":
			if(s != null)
				new MainGame(nomePlayer, 2,menu2);
			break;
		case "frameLV1cla":
			v.load("classifiche.bin");
			v.getC(0).add(new Partita("null", 999999999));
			v.getC(0).add(new Partita("null", 999999999));
			v.getC(0).add(new Partita("null", 999999999));
			new ShlClassifica(v.getC(0));
			classifica.closeAll();
			try {
				classifica.join();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			break;
		}


	}

	public void AvvioScelta(String nome) {
		this.nomePlayer = nome;
		System.err.println(nomePlayer);
		if(s == null) {
			s = new SceltaLivelli(menu2);
			s.start();			
		}else {
			s.setVisibile();			
		}
	}

	public void AvvioSceltaCla() {
		System.err.println(nomePlayer);
		if(c == null) {
			c = new SceltaClassifica(menu2);
			c.setVet(v);			
			c.start();
		}else {
			c.setVisible();			
		}
	}

	public int scelta() {
		return scelta;
	}
	public void setSelected(int sel) {
		selected = sel;
	}
	public void windowLostFocus(WindowEvent e) {
	}
}
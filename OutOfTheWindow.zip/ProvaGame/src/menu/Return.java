package menu;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

import WindowLogic.Win;

public class Return {
	Object o,caso;
	Menu current;
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	private GamePanel panel = new GamePanel();
	private JFrame frame = new JFrame();
	ReturnListener input;
	SceltaClassifica scelta;
	InNome nome;
	SceltaLivelli level;
	Win win;
	public Return(Object o,Menu current) {
		
		this.current = current;
		this.o = o;
		frame.setLocation(screenSize.width / 2 - 100, screenSize.height - 240);
		frame.setSize(200, 200);
		frame.setVisible(true);
		input = new ReturnListener(this);
		frame.addWindowFocusListener(input) ;
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panel= new GamePanel();
		frame.add(panel);
		panel.paint(0, 0, 200, 200,"back");
		
		frame.requestFocusInWindow(null);
	}
	
	
	public void backToLast() {
		
		if (current instanceof Menu) {
			// Torna indietro a Menu
			Menu menu =(Menu)current;
			if (o instanceof SceltaLivelli) {
				level = (SceltaLivelli) o;
				System.out.println("SceltaLivelli");
			}
			if (o instanceof InNome) {
				nome = (InNome) o;
				System.out.println("InNome");
				
			}
			if(o instanceof SceltaClassifica) {
				scelta = (SceltaClassifica) o;
				System.out.println("Classifica");
				scelta.closeAll();
			}
			if(o instanceof Win) {
				win = (Win) o;
				System.out.println("Classifica");
				win.closeAll();
			}
			//chiudere il current
			
			menu.openAll();
			
			if(scelta != null)
				scelta.closeAll();
			
			if(nome != null)
				nome.closeAll();
			
			if(level != null)
				level.closeAll();
			System.out.println("ciao2");
		}
		
		
	}
	public void setVisible(boolean set) {
		input.setClick(0);
		frame.setVisible(set);
	}
}

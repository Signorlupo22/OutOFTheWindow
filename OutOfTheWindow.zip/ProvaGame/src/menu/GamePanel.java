/*
 * motore grafico (ancora non so cosa sia)
 * 
*/

package menu;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.*;

import Utility.LoadSave;

public class GamePanel extends JPanel {

	private boolean moving = false;
	private BufferedImage img = null;
	int x,y,width,height,choose;

	public GamePanel() {
	}

	public void paint(int x, int y, int width, int height, String choose) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		super.paintComponent(getGraphics());
		img = null;
		while (img == null) {
			img = LoadSave.GetSpriteAtlas(choose + ".png");
		}
		
		repaint();
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponents(g);
		g.drawImage(img, x, y, width, height, null);
	}
}

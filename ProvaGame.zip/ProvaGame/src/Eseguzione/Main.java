package Eseguzione;

import menu.GestMenu;

public class Main {
	
	public static void main(String[] args) {
		GestMenu m = new GestMenu();
		m.start();
	}
	
}

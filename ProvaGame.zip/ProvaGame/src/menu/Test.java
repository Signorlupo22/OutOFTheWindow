package menu;

public class Test {
	
	public static void main(String[] args) {
		GestMenu m = new GestMenu();
		m.start();
	}
	
}

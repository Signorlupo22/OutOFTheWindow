package menu;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class SceltaLivelli extends Thread{
	
	static int LARGHEZZA = 0;
	final static int nFrame = 3;
	final static int DIMENSIONE=400;
	static int DELAY=20;
	private JFrame[] frame = new JFrame[nFrame];
	private GamePanel[] panel = new GamePanel[nFrame];
	private FrameSelectionListener[] input = new FrameSelectionListener[nFrame];
	private Menu m;
	private Return r;
	
	public SceltaLivelli(Menu m) {
		this.m = m;
	}
	
	public void run() {
		initClass();
		drawImg();
	}
	private void drawImg(){

		for (int i = 0; i < nFrame; i++) {
			frame[i].setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame[i].setResizable(false);
			input[i] = new FrameSelectionListener(frame[i].getTitle());
			frame[i].addWindowFocusListener(input[i]);
			
			frame[i].setVisible(true);

			switch (i) {
				case 0:
					panel[0].paint(0, 0, DIMENSIONE, DIMENSIONE,"Level1");
					break;
				case 1:
					panel[1].paint(0, 0, DIMENSIONE, DIMENSIONE,"livello2");
					break;
				case 2:
					panel[2].paint(0, 0, DIMENSIONE, DIMENSIONE,"livello3");
					break;
			}
			
			try {
				Thread.sleep(DELAY);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}		
	}
	private void initClass() {
	r = new Return(this, m);
		
		for (int i = 0; i < nFrame; i++) {
			frame[i] = new JFrame("frameLV"+(i+1));
			panel[i] = new GamePanel();

			frame[i].add(panel[i]);
			
		}

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		
		frame[0].setLocation(screenSize.width / 2 - 600 + LARGHEZZA, screenSize.height / 2 -200);
		frame[0].setSize(DIMENSIONE, DIMENSIONE);
		frame[1].setLocation(screenSize.width / 2 - 200 + LARGHEZZA, screenSize.height / 2 -200);
		frame[1].setSize(DIMENSIONE, DIMENSIONE);
		frame[2].setLocation(screenSize.width / 2 + 200 + LARGHEZZA, screenSize.height / 2 -200);
		frame[2].setSize(DIMENSIONE, DIMENSIONE);
	}
	public void closeAll() {
		for (int i = 0; i < nFrame; i++) {
			frame[i].dispose();
			input[i].setSelected(0);
			r.setVisible(false);
		}
	}
	public void setVisibile() {
		r.setVisible(true);
		for (int i = 0; i < nFrame; i++) {
			frame[i].setVisible(true);
			
		}
		
	}
	

}

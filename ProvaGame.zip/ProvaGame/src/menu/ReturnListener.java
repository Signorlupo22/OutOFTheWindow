package menu;

import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

public class ReturnListener implements WindowFocusListener{
	
	Return t;
	int click = 0;
	public ReturnListener(Return t) {
		this.t = t;
	}
	@Override
	public void windowGainedFocus(WindowEvent e) {
		click ++;
		if(click == 1) return;
		
		t.backToLast();
		
	}

	@Override
	public void windowLostFocus(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	public void setClick(int click) {
		this.click = click;
	}

}

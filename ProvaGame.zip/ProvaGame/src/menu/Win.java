package menu;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import Utility.LoadSave;

public class Win extends JFrame{
	private JPanel contentPane;
	private static String nome;
	protected static volatile boolean controllo=false;
	private Return r;
	private Menu m;
	
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public Win(long time, Menu m) {
		
		r = new Return(this, m); 
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(screenSize.width / 2 - 231, screenSize.height / 2 -200, 462, 246);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		BufferedImage tmp = LoadSave.GetSpriteAtlas("Map.png");
		
		JLabel lblNewLabel = new JLabel("HAI VINTO");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 140, 0));
		lblNewLabel.setFont(new Font("CityStencil", Font.PLAIN, 34));
		lblNewLabel.setBounds(0, 0, 446, 96);
		contentPane.add(lblNewLabel);
		
		JLabel lblTempo = new JLabel("TEMPO " + time);
		lblTempo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTempo.setForeground(new Color(255, 140, 0));
		lblTempo.setFont(new Font("CityStencil", Font.PLAIN, 34));
		lblTempo.setBounds(0, 62, 446, 51);
		contentPane.add(lblTempo);
		//Image goldImg = tmp.getScaledInstance(150,225, Image.SCALE_SMOOTH);
		JLabel lblNewLabel_1 = new JLabel(new ImageIcon(tmp));
		lblNewLabel_1.setBackground(new Color(255, 140, 0));
		lblNewLabel_1.setBounds(0, 0, 446, 207);
		contentPane.add(lblNewLabel_1);
		setVisible();
		
		
	}
	
	public static String getNome() {
		return nome;
	}

	public void closeAll() {
		r.setVisible(false);
		//setVisible(false);
		dispose();
	}
	public void setVisible() {
		r.setVisible(true);
		setVisible(true);
	}
}

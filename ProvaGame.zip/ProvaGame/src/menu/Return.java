package menu;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

public class Return {
	Object o, caso;
	Menu current;
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	private GamePanel panel = new GamePanel();
	private JFrame frame = new JFrame();
	ReturnListener input;
	SceltaClassifica scelta;
	InNome nome;
	SceltaLivelli level;
	Win win;

	public Return(Object o, Menu current) {

		this.current = current;
		this.o = o;
		frame.setLocation(screenSize.width / 2 - 100, screenSize.height - 240);
		frame.setSize(200, 200);
		frame.setVisible(true);
		input = new ReturnListener(this);
		frame.addWindowFocusListener(input);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panel = new GamePanel();
		frame.add(panel);
		panel.paint(0, 0, 200, 200, "back");
		frame.requestFocusInWindow(null);
	}

	public void backToLast() {

		if (o instanceof SceltaLivelli) {
			GestMenu.gest.closeSceltaLivelli();
			GestMenu.gest.openMenu();
		}
		if (o instanceof InNome) {
			GestMenu.gest.closeInNome();
			GestMenu.gest.openMenu();
		}
		if (o instanceof SceltaClassifica) {
			GestMenu.gest.closeSceltaClassifica();
			GestMenu.gest.openMenu();
		}
		if (o instanceof Win) {
			GestMenu.gest.closeWin();
			GestMenu.gest.openMenu();
		}

	}

	public void setVisible(boolean set) {
		input.setClick(0);
		frame.setVisible(set);
	}
}

package menu;

import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

import javax.swing.JFrame;

import classifica.*;
import levels.MainGame;

public class FrameSelectionListener implements WindowFocusListener {
	
	public VetClassifica v = VetClassifica.load("classifiche.bin");
	private String shellname;
	int selected = 0;

	public FrameSelectionListener() {
	}


	public FrameSelectionListener(String name) {
		shellname = name;
	}



	public void windowGainedFocus(WindowEvent e) {
		if (!(e.getSource() instanceof JFrame))return;
		selected++;

		if (selected <= 1)return;

		switch (shellname) {

		case "frame4":
			GestMenu.gest.openSceltaClassifica();
			GestMenu.gest.closeMenu();
			break;
		case "frame5":
			GestMenu.gest.openInNome();
			GestMenu.gest.closeMenu();
			break;
		case "frame6":
			System.out.println("coming Soon");
			break;
		case "frameLV1":
			GestMenu.gest.openLivello(1);
			GestMenu.gest.closeSceltaLivelli();
			break;
		case "frameLV2":
			//GestMenu.gest.openLivello(2);
			//GestMenu.gest.closeSceltaLivelli();
			break;
		case "frameLV3":
			//GestMenu.gest.openLivello(3);
			//GestMenu.gest.closeSceltaLivelli();
			break;
		case "frameLV1cla":
			GestMenu.gest.openClassifica(1);
			GestMenu.gest.closeSceltaClassifica();
			break;
		}


	}

	public void setSelected(int sel) {
		selected = sel;
	}
	public void windowLostFocus(WindowEvent e) {
	}
	
}
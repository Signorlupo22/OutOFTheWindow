package menu;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

import classifica.Partita;
import classifica.ShlClassifica;
import classifica.VetClassifica;

public class SceltaClassifica extends Thread{
	
	static int LARGHEZZA = 0;
	final static int nFrame = 3;
	final static int DIMENSIONE=400;
	final static int DELAY = 20;
	private JFrame[] frame = new JFrame[nFrame];
	private FrameSelectionListener[] input = new FrameSelectionListener[nFrame];
	private GamePanel[] panel = new GamePanel[nFrame];
	private VetClassifica vet;
	private Menu m;
	private Return r;
	
	public SceltaClassifica(Menu m) {
		this.m = m;
	}
	
	public void run() {
		intiClass();
		drawImage();
	}
	private void intiClass() {
		for (int i = 0; i < nFrame; i++) {
			frame[i] = new JFrame("frameLV"+(i+1+"cla"));
			panel[i] = new GamePanel();

			frame[i].add(panel[i]);
			
		}
		r = new Return(this, m);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		
		frame[0].setLocation(screenSize.width / 2 - 600 + LARGHEZZA, screenSize.height / 2 -200);
		frame[0].setSize(DIMENSIONE, DIMENSIONE);
		frame[1].setLocation(screenSize.width / 2 - 200 + LARGHEZZA, screenSize.height / 2 -200);
		frame[1].setSize(DIMENSIONE, DIMENSIONE);
		frame[2].setLocation(screenSize.width / 2 + 200 + LARGHEZZA, screenSize.height / 2 -200);
		frame[2].setSize(DIMENSIONE, DIMENSIONE);
	}
	private void drawImage() {
		for (int i = 0; i < nFrame; i++) {
			frame[i].setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame[i].setResizable(false);
			input[i] = new FrameSelectionListener(frame[i].getTitle());
			frame[i].addWindowFocusListener(input[i]);
			frame[i].requestFocusInWindow(null);
			frame[i].setVisible(true);

			switch (i) {
				case 0:
					panel[0].paint(0, 0, DIMENSIONE, DIMENSIONE,"Level1");
					break;
				case 1:
					panel[1].paint(0, 0, DIMENSIONE, DIMENSIONE,"livello2");
					break;
				case 2:
					panel[2].paint(0, 0, DIMENSIONE, DIMENSIONE,"livello3");
					break;
			}
			
			try {
				Thread.sleep(DELAY);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	public void closeAll() {
		for (int i = 0; i < nFrame; i++) {
			input[i].setSelected(0);
			frame[i].dispose();
			r.setVisible(false);
			
		}
	}
	public void setVet(VetClassifica vet) {
		this.vet=vet;
	}
	public void setVisible() {
		
		r.setVisible(true);
		for (int i = 0; i < nFrame; i++) {
			if(input[i]!= null)
				input[i].setSelected(0);
			if(frame[i] != null)
				frame[i].setVisible(true);
			try {
				Thread.sleep(DELAY);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
